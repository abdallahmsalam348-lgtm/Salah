package com.salaty.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import java.util.TimeZone
import kotlin.math.abs

object AdhanScheduler {
    const val CHANNEL_ID = "adhan_v1"

    // القاهرة كموقع افتراضي
    const val DEFAULT_LAT = 30.0444
    const val DEFAULT_LNG = 31.2357

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("salaty", Context.MODE_PRIVATE)

    fun lat(ctx: Context): Double = prefs(ctx).getString("lat", null)?.toDoubleOrNull() ?: DEFAULT_LAT
    fun lng(ctx: Context): Double = prefs(ctx).getString("lng", null)?.toDoubleOrNull() ?: DEFAULT_LNG
    fun alertsEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("alerts", true)

    private fun alarmIntent(ctx: Context, prayer: Prayer?, time: Long): PendingIntent {
        val i = Intent(ctx, AdhanReceiver::class.java)
        if (prayer != null) {
            i.putExtra("prayer", prayer.name)
            i.putExtra("time", time)
        }
        return PendingIntent.getBroadcast(
            ctx, 1, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(ctx, null, 0L))
    }

    /** يجدول تنبيه الصلاة القادمة بعد الوقت المعطى. */
    fun scheduleNext(ctx: Context, after: Long = System.currentTimeMillis()) {
        if (!alertsEnabled(ctx)) {
            cancel(ctx)
            return
        }
        val (prayer, time) = PrayerCalculator.next(after, lat(ctx), lng(ctx), TimeZone.getDefault())
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val showIntent = PendingIntent.getActivity(
            ctx, 2, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(time, showIntent), alarmIntent(ctx, prayer, time))
        } catch (e: SecurityException) {
            // نادرًا ما يحصل، نتجاهله بدل ما التطبيق يقفل
        }
    }

    private fun soundUri(ctx: Context): Uri {
        // لو حطيت ملف adhan.mp3 داخل res/raw هيتم استخدامه تلقائيًا
        val id = ctx.resources.getIdentifier("adhan", "raw", ctx.packageName)
        return if (id != 0) {
            Uri.parse("android.resource://" + ctx.packageName + "/" + id)
        } else {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        }
    }

    fun showNotification(ctx: Context, prayer: Prayer) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val sound = soundUri(ctx)

        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "الأذان", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "تنبيه دخول وقت الصلاة"
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ch.setSound(sound, attrs)
            nm.createNotificationChannel(ch)
        }

        val open = PendingIntent.getActivity(
            ctx, 3, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val b = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(ctx, CHANNEL_ID)
        } else {
            Notification.Builder(ctx).setSound(sound)
        }
        b.setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("حان الآن موعد صلاة " + prayer.ar)
            .setContentText("حيّ على الصلاة")
            .setContentIntent(open)
            .setAutoCancel(true)

        try {
            nm.notify(100 + prayer.ordinal, b.build())
        } catch (e: SecurityException) {
            // إذن الإشعارات مش ممنوح
        }
    }
}

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val now = System.currentTimeMillis()
        val time = intent.getLongExtra("time", now)
        val name = intent.getStringExtra("prayer")
        val prayer = try {
            if (name != null) Prayer.valueOf(name) else null
        } catch (e: IllegalArgumentException) {
            null
        }
        // نتأكد إن التنبيه في وقته (مش متأخر جدًا)
        if (prayer != null && abs(now - time) < 10 * 60_000L) {
            AdhanScheduler.showNotification(context, prayer)
        }
        AdhanScheduler.scheduleNext(context, maxOf(now, time) + 1000L)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AdhanScheduler.scheduleNext(context)
    }
}
