package com.salaty.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : Activity() {

    private class City(val name: String, val lat: Double, val lng: Double)

    private val cities = listOf(
        City("القاهرة", 30.0444, 31.2357),
        City("الإسكندرية", 31.2001, 29.9187),
        City("الجيزة", 30.0131, 31.2089),
        City("أسوان", 24.0889, 32.8998),
        City("مكة المكرمة", 21.4225, 39.8262),
        City("المدينة المنورة", 24.4672, 39.6111),
        City("الرياض", 24.7136, 46.6753),
        City("جدة", 21.4858, 39.1925),
        City("دبي", 25.2048, 55.2708),
        City("الكويت", 29.3759, 47.9774),
        City("الدوحة", 25.2854, 51.5310),
        City("عمّان", 31.9454, 35.9284),
        City("بغداد", 33.3152, 44.3661),
        City("الخرطوم", 15.5007, 32.5599),
        City("الدار البيضاء", 33.5731, -7.5898),
        City("الجزائر", 36.7538, 3.0588),
        City("تونس", 36.8065, 10.1815),
        City("إسطنبول", 41.0082, 28.9784),
        City("لندن", 51.5072, -0.1276)
    )

    private val BG = Color.parseColor("#0F1B2D")
    private val CARD = Color.parseColor("#1B2A41")
    private val GOLD = Color.parseColor("#F2C14E")
    private val GREEN = Color.parseColor("#2ECC71")
    private val MUTED = Color.parseColor("#9FB3C8")

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var tvDate: TextView
    private lateinit var tvLocation: TextView
    private lateinit var tvNextName: TextView
    private lateinit var tvCountdown: TextView
    private val rowBoxes = HashMap<Prayer, LinearLayout>()
    private val rowNames = HashMap<Prayer, TextView>()
    private val rowTimes = HashMap<Prayer, TextView>()

    private var lat = AdhanScheduler.DEFAULT_LAT
    private var lng = AdhanScheduler.DEFAULT_LNG
    private var nextTime = 0L
    private var shownDay = -1

    private val arLocale = Locale("ar", "EG")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun prefs() = AdhanScheduler.prefs(this)

    // ---------------------------------------------------------------- UI

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.cornerRadius = dp(16).toFloat()
        c.background = bg
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#0F6B4F"))
        bg.cornerRadius = dp(12).toFloat()
        b.background = bg
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))
        scroll.addView(root)
        setContentView(scroll)

        // العنوان
        val header = card()
        val title = text("صلاتي", 30f, GOLD, true)
        title.gravity = Gravity.CENTER
        tvDate = text("", 14f, MUTED)
        tvDate.gravity = Gravity.CENTER
        tvLocation = text("", 14f, Color.WHITE)
        tvLocation.gravity = Gravity.CENTER
        header.addView(title)
        header.addView(tvDate)
        header.addView(tvLocation)
        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.setPadding(0, dp(10), 0, 0)
        btnRow.addView(button("📍 موقعي") { fetchLocation(true) })
        btnRow.addView(button("🏙 اختيار مدينة") { chooseCity() })
        header.addView(btnRow)
        root.addView(header)

        // الصلاة القادمة + العد التنازلي
        val nextCard = card()
        tvNextName = text("", 18f, MUTED)
        tvNextName.gravity = Gravity.CENTER
        tvCountdown = text("--:--:--", 44f, Color.WHITE, true)
        tvCountdown.gravity = Gravity.CENTER
        nextCard.addView(tvNextName)
        nextCard.addView(tvCountdown)
        root.addView(nextCard)

        // جدول المواقيت
        val timesCard = card()
        for (p in Prayer.values()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(dp(12), dp(12), dp(12), dp(12))
            val n = text(p.ar, 18f, Color.WHITE)
            val nlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            n.layoutParams = nlp
            val t = text("", 18f, Color.WHITE, true)
            row.addView(n)
            row.addView(t)
            rowBoxes[p] = row
            rowNames[p] = n
            rowTimes[p] = t
            timesCard.addView(row)
        }
        root.addView(timesCard)

        // التنبيه + القبلة
        val optCard = card()
        val sw = Switch(this)
        sw.text = "تنبيه عند دخول وقت الصلاة"
        sw.setTextColor(Color.WHITE)
        sw.textSize = 16f
        sw.isChecked = AdhanScheduler.alertsEnabled(this)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs().edit().putBoolean("alerts", checked).apply()
            if (checked) {
                AdhanScheduler.scheduleNext(this)
                askNotificationPermission()
            } else {
                AdhanScheduler.cancel(this)
            }
        }
        optCard.addView(sw)
        val qiblaRow = LinearLayout(this)
        qiblaRow.orientation = LinearLayout.HORIZONTAL
        qiblaRow.setPadding(0, dp(12), 0, 0)
        qiblaRow.addView(button("🧭 اتجاه القبلة") {
            startActivity(Intent(this, QiblaActivity::class.java))
        })
        optCard.addView(qiblaRow)
        root.addView(optCard)

        // الموقع المحفوظ
        lat = AdhanScheduler.lat(this)
        lng = AdhanScheduler.lng(this)
        updateLocationLabel()
        refresh()

        // الأذونات عند أول تشغيل
        if (!prefs().getBoolean("asked", false)) {
            prefs().edit().putBoolean("asked", true).apply()
            val perms = ArrayList<String>()
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        } else if (prefs().getString("mode", "gps") == "gps") {
            fetchLocation(false)
        }

        AdhanScheduler.scheduleNext(this)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    // ---------------------------------------------------------------- Logic

    private val ticker = object : Runnable {
        override fun run() {
            val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
            val left = nextTime - System.currentTimeMillis()
            if (left <= 0L || today != shownDay) {
                refresh()
            } else {
                val s = left / 1000
                tvCountdown.text = String.format(
                    arLocale, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60
                )
            }
            handler.postDelayed(this, 1000L)
        }
    }

    private fun refresh() {
        val tz = TimeZone.getDefault()
        val cal = Calendar.getInstance(tz)
        shownDay = cal.get(Calendar.DAY_OF_YEAR)
        val times = PrayerCalculator.timesForDate(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH),
            lat, lng
        )
        val fmt = SimpleDateFormat("hh:mm a", arLocale)
        fmt.timeZone = tz
        for (p in Prayer.values()) {
            rowTimes[p]?.text = fmt.format(Date(times.getValue(p)))
        }

        val now = System.currentTimeMillis()
        val (np, nt) = PrayerCalculator.next(now, lat, lng, tz)
        nextTime = nt

        for (p in Prayer.values()) {
            val box = rowBoxes[p] ?: continue
            val bg = GradientDrawable()
            bg.cornerRadius = dp(10).toFloat()
            if (p == np) {
                bg.setColor(Color.parseColor("#0F6B4F"))
                rowNames[p]?.setTextColor(Color.WHITE)
            } else {
                bg.setColor(Color.TRANSPARENT)
                rowNames[p]?.setTextColor(if (p == Prayer.SUNRISE) MUTED else Color.WHITE)
            }
            box.background = bg
        }

        tvNextName.text = "الصلاة القادمة: " + np.ar
        val dateFmt = SimpleDateFormat("EEEE d MMMM yyyy", arLocale)
        dateFmt.timeZone = tz
        tvDate.text = dateFmt.format(Date())
    }

    private fun updateLocationLabel() {
        val label = prefs().getString("label", "القاهرة (افتراضي)")
        tvLocation.text = "الموقع: " + label
    }

    private fun saveLocation(newLat: Double, newLng: Double, label: String, mode: String) {
        lat = newLat
        lng = newLng
        prefs().edit()
            .putString("lat", newLat.toString())
            .putString("lng", newLng.toString())
            .putString("label", label)
            .putString("mode", mode)
            .apply()
        updateLocationLabel()
        refresh()
        AdhanScheduler.scheduleNext(this)
    }

    private fun chooseCity() {
        val names = ArrayList<String>()
        for (c in cities) names.add(c.name)
        AlertDialog.Builder(this)
            .setTitle("اختر المدينة")
            .setItems(names.toTypedArray()) { _, i ->
                val c = cities[i]
                saveLocation(c.lat, c.lng, c.name, "city")
            }
            .show()
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            applyGps(location)
        }

        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun applyGps(l: Location) {
        val label = String.format(Locale.US, "موقعي (%.2f, %.2f)", l.latitude, l.longitude)
        saveLocation(l.latitude, l.longitude, label, "gps")
    }

    private fun fetchLocation(userAction: Boolean) {
        if (!hasLocationPermission()) {
            if (userAction) {
                requestPermissions(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ), 1
                )
            }
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p)
                val cur = best
                if (l != null && (cur == null || l.time > cur.time)) best = l
            }
            val found = best
            if (found != null) {
                applyGps(found)
                return
            }
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider == null) {
                if (userAction) toast("فعّل خدمة الموقع (GPS) من إعدادات الجهاز")
                return
            }
            if (userAction) toast("جاري تحديد الموقع...")
            lm.requestSingleUpdate(provider, locListener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            if (userAction) toast("إذن الموقع غير مفعّل")
        }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && hasLocationPermission()) {
            fetchLocation(true)
        }
    }
}
