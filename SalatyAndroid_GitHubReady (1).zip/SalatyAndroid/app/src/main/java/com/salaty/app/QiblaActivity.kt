package com.salaty.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

class CompassView(ctx: Context) : View(ctx) {
    var heading = 0f
    var qibla = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) * 0.9f

        val diff = ((qibla - heading + 540f) % 360f) - 180f
        val aligned = abs(diff) < 4f

        // خلفية القرص
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#1B2A41")
        c.drawCircle(cx, cy, r, paint)

        // الإطار (أخضر لو متجه للقبلة)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 10f
        paint.color = if (aligned) Color.parseColor("#2ECC71") else Color.parseColor("#3C5170")
        c.drawCircle(cx, cy, r, paint)

        // علامات الاتجاهات (تدور عكس اتجاه الجهاز عشان الشمال يفضل شمال)
        c.save()
        c.rotate(-heading, cx, cy)
        paint.strokeWidth = 4f
        paint.color = Color.parseColor("#6C819B")
        var a = 0
        while (a < 360) {
            val len = if (a % 90 == 0) r * 0.12f else r * 0.06f
            c.drawLine(cx, cy - r + 14f, cx, cy - r + 14f + len, paint)
            c.rotate(30f, cx, cy)
            a += 30
        }
        // علامة الشمال
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#E74C3C")
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * 0.14f
        c.drawText("شمال", cx, cy - r + r * 0.34f, paint)
        c.restore()

        // سهم القبلة
        c.save()
        c.rotate(qibla - heading, cx, cy)
        val arrow = Path()
        arrow.moveTo(cx, cy - r * 0.72f)
        arrow.lineTo(cx - r * 0.12f, cy)
        arrow.lineTo(cx + r * 0.12f, cy)
        arrow.close()
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#F2C14E")
        c.drawPath(arrow, paint)
        // الكعبة (مربع صغير على رأس السهم)
        paint.color = Color.BLACK
        val k = r * 0.07f
        c.drawRect(cx - k, cy - r * 0.86f, cx + k, cy - r * 0.86f + 2 * k, paint)
        paint.color = Color.parseColor("#F2C14E")
        c.drawRect(cx - k, cy - r * 0.86f + k * 0.5f, cx + k, cy - r * 0.86f + k * 0.7f, paint)
        c.restore()

        // نقطة المركز
        paint.color = Color.WHITE
        c.drawCircle(cx, cy, r * 0.04f, paint)
    }
}

class QiblaActivity : Activity(), SensorEventListener {

    private lateinit var compass: CompassView
    private lateinit var tvHeading: TextView
    private lateinit var sm: SensorManager

    private val gravity = FloatArray(3)
    private val geomagnetic = FloatArray(3)
    private var hasGravity = false
    private var hasMag = false
    private var declination = 0f

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.parseColor("#0F1B2D")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val lat = AdhanScheduler.lat(this)
        val lng = AdhanScheduler.lng(this)
        val bearing = PrayerCalculator.qiblaBearing(lat, lng)
        val km = PrayerCalculator.distanceToKaabaKm(lat, lng)
        declination = GeomagneticField(lat.toFloat(), lng.toFloat(), 0f, System.currentTimeMillis()).declination

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))

        val title = TextView(this)
        title.text = "اتجاه القبلة"
        title.textSize = 26f
        title.setTextColor(Color.parseColor("#F2C14E"))
        title.gravity = Gravity.CENTER
        root.addView(title)

        val info = TextView(this)
        info.text = String.format(
            Locale.US, "زاوية القبلة: %d° من الشمال  •  المسافة للكعبة: %,d كم",
            bearing.roundToInt(), km.roundToInt()
        )
        info.textSize = 14f
        info.setTextColor(Color.parseColor("#9FB3C8"))
        info.gravity = Gravity.CENTER
        info.setPadding(0, dp(8), 0, dp(8))
        root.addView(info)

        compass = CompassView(this)
        compass.qibla = bearing.toFloat()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        compass.layoutParams = lp
        root.addView(compass)

        tvHeading = TextView(this)
        tvHeading.textSize = 16f
        tvHeading.setTextColor(Color.WHITE)
        tvHeading.gravity = Gravity.CENTER
        tvHeading.setPadding(0, dp(8), 0, dp(4))
        root.addView(tvHeading)

        val hint = TextView(this)
        hint.text = "امسك الهاتف أفقيًا بعيدًا عن المعادن والمغناطيس. لو الاتجاه غير دقيق حرّك الهاتف على شكل ٨."
        hint.textSize = 12f
        hint.setTextColor(Color.parseColor("#9FB3C8"))
        hint.gravity = Gravity.CENTER
        root.addView(hint)

        setContentView(root)

        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        if (sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) == null ||
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null
        ) {
            tvHeading.text = "الجهاز لا يحتوي على بوصلة. استخدم زاوية القبلة أعلاه."
        }
    }

    override fun onResume() {
        super.onResume()
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI)
        if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI)
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val alpha = 0.85f
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            for (i in 0..2) gravity[i] = alpha * gravity[i] + (1 - alpha) * event.values[i]
            hasGravity = true
        } else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
            for (i in 0..2) geomagnetic[i] = alpha * geomagnetic[i] + (1 - alpha) * event.values[i]
            hasMag = true
        }
        if (!hasGravity || !hasMag) return

        val r = FloatArray(9)
        val i = FloatArray(9)
        if (SensorManager.getRotationMatrix(r, i, gravity, geomagnetic)) {
            val o = FloatArray(3)
            SensorManager.getOrientation(r, o)
            var az = Math.toDegrees(o[0].toDouble()).toFloat() + declination
            az = ((az % 360f) + 360f) % 360f
            compass.heading = az
            compass.invalidate()

            val diff = ((compass.qibla - az + 540f) % 360f) - 180f
            tvHeading.text = if (abs(diff) < 4f) {
                "أنت متجه نحو القبلة ✓"
            } else {
                "لف " + (if (diff > 0) "يمينًا" else "يسارًا") + " " + abs(diff).roundToInt() + "°"
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
