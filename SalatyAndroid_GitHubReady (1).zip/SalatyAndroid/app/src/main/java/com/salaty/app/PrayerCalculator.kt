package com.salaty.app

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

enum class Prayer(val ar: String) {
    FAJR("الفجر"),
    SUNRISE("الشروق"),
    DHUHR("الظهر"),
    ASR("العصر"),
    MAGHRIB("المغرب"),
    ISHA("العشاء")
}

/**
 * حساب مواقيت الصلاة محليًا بدون إنترنت.
 * الطريقة: الهيئة المصرية العامة للمساحة (الفجر 19.5° والعشاء 17.5°) والعصر بالمذهب الشافعي (ظل = 1).
 */
object PrayerCalculator {
    private const val FAJR_ANGLE = 19.5
    private const val ISHA_ANGLE = 17.5
    private const val RISE_SET_ANGLE = 0.833
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LNG = 39.8262

    private class Sun(val decl: Double, val eqt: Double)

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double) = ((a % 360.0) + 360.0) % 360.0
    private fun fixHour(h: Double) = ((h % 24.0) + 24.0) % 24.0

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun sun(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        return Sun(decl, eqt)
    }

    /** مواقيت يوم معين (التاريخ بتوقيت الجهاز) بالملي ثانية. */
    fun timesForDate(
        year: Int,
        month: Int,
        day: Int,
        lat: Double,
        lng: Double
    ): Map<Prayer, Long> {
        val jd = julian(year, month, day) - lng / (15.0 * 24.0)

        fun midDay(t: Double): Double = fixHour(12.0 - sun(jd + t).eqt)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jd + t).decl
            val noon = midDay(t)
            val v = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) /
                (cos(rad(decl)) * cos(rad(lat)))
            val r = deg(acos(v.coerceIn(-1.0, 1.0))) / 15.0
            return noon + if (ccw) -r else r
        }

        fun asrTime(t: Double): Double {
            val decl = sun(jd + t).decl
            // معامل الظل = 1 (الشافعي)
            val angle = -deg(atan(1.0 / (1.0 + tan(rad(abs(lat - decl))))))
            return angleTime(angle, t, false)
        }

        val raw = mapOf(
            Prayer.FAJR to angleTime(FAJR_ANGLE, 5.0 / 24.0, true),
            Prayer.SUNRISE to angleTime(RISE_SET_ANGLE, 6.0 / 24.0, true),
            Prayer.DHUHR to midDay(12.0 / 24.0),
            Prayer.ASR to asrTime(13.0 / 24.0),
            Prayer.MAGHRIB to angleTime(RISE_SET_ANGLE, 18.0 / 24.0, false),
            Prayer.ISHA to angleTime(ISHA_ANGLE, 18.0 / 24.0, false)
        )

        val utcMidnight = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(year, month - 1, day, 0, 0, 0)
        }.timeInMillis

        val out = LinkedHashMap<Prayer, Long>()
        for (p in Prayer.values()) {
            // الساعة بالتوقيت العالمي = الوقت الخام - خط الطول/15
            val utcHours = raw.getValue(p) - lng / 15.0
            val ms = utcMidnight + (utcHours * 3_600_000.0).roundToLong()
            out[p] = (ms / 60_000.0).roundToLong() * 60_000L
        }
        return out
    }

    /** الصلاة القادمة (بدون الشروق) بعد وقت معين. */
    fun next(after: Long, lat: Double, lng: Double, tz: TimeZone): Pair<Prayer, Long> {
        val list = listOf(Prayer.FAJR, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        for (dayOffset in 0..2) {
            val c = Calendar.getInstance(tz)
            c.timeInMillis = after
            c.add(Calendar.DAY_OF_MONTH, dayOffset)
            val t = timesForDate(
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH) + 1,
                c.get(Calendar.DAY_OF_MONTH),
                lat,
                lng
            )
            for (p in list) {
                val v = t.getValue(p)
                if (v > after) return Pair(p, v)
            }
        }
        return Pair(Prayer.FAJR, after + 24L * 3_600_000L)
    }

    /** زاوية القبلة من الشمال الحقيقي (0..360). */
    fun qiblaBearing(lat: Double, lng: Double): Double {
        val phi = rad(lat)
        val kLat = rad(KAABA_LAT)
        val dl = rad(KAABA_LNG - lng)
        val y = sin(dl)
        val x = cos(phi) * tan(kLat) - sin(phi) * cos(dl)
        return fixAngle(deg(atan2(y, x)))
    }

    /** المسافة إلى الكعبة بالكيلومتر. */
    fun distanceToKaabaKm(lat: Double, lng: Double): Double {
        val r = 6371.0
        val dLat = rad(KAABA_LAT - lat)
        val dLng = rad(KAABA_LNG - lng)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(rad(lat)) * cos(rad(KAABA_LAT)) * sin(dLng / 2) * sin(dLng / 2)
        return 2 * r * atan2(sqrt(a), sqrt(1 - a))
    }
}
